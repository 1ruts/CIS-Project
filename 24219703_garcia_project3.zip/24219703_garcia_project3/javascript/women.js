/*
Student ID: 24219703
Student Name: Albin Garcia
 */

const products = [
    { id: 1, prod_name: "Wmns Dunk Low Next Nature 'Gym Red'", price: 90, image: "Wmns(1).webp" },
    { id: 2, prod_name: "Wmns Dunk Low 'Orange Paisley'",  price: 600, image: "Wmns(2).webp" },
    { id: 3, prod_name: "Wmns Air Jordan 1 Low 'Marina Blue'",  price: 100, image: "Wmns(3).webp" },
    { id: 4, prod_name: "Wmns Dunk Low Next Nature 'Blue Tint'",  price: 90, image: "Wmns(4).webp" },
    { id: 5, prod_name: "Wmns Air Jordan 4 Retro 'Frozen Moments'",  price: 290, image: "Wmns(5).webp" },
    { id: 6, prod_name: "Wmns Dunk Low 'Cacao Wow'",  price: 90, image: "Wmns(6).webp" },
    { id: 7, prod_name: "Wmns Air Jordan 4 Retro 'Metallic Gold'",  price: 220, image: "Wmns(7).webp" },
    { id: 8, prod_name: "Wmns Air Jordan 4 Retro 'Vivid Sulfur'",  price: 120, image: "Wmns(8).webp" },
    { id: 9, prod_name: "Wmns Air Jordan 3 Retro 'Georgia Peach'",  price: 150, image: "Wmns(9).webp" },
    { id: 10, prod_name: "Wmns Dunk Low 'Valentine's Day 2024'",  price: 100, image: "Wmns(10).webp" },
    { id: 11, prod_name: "Wmns Dunk Low LX 'Gorge Green Ostrich'",  price: 90, image: "Wmns(11).webp" },
    { id: 12, prod_name: "Travis Scott x Wmns Air Jordan 1 Retro Low OG SP 'Canary'",  price: 220, image: "Wmns(12).webp" },
    { id: 13, prod_name: "Wmns Gel 1130 'White Carrier Grey Lilac'",  price: 150, image: "Wmns(13).webp" },
    { id: 14, prod_name: "Wmns Samba OG 'Cream White Sand Strata'",  price: 95, image: "Wmns(14).webp" },
    { id: 15, prod_name: "Wmns Dunk Low 'Give Her Flowers'",  price: 100, image: "Wmns(15).webp" },
    { id: 16, prod_name: "Wmns Gazelle Indoor 'Sandy Pink Gum'",  price: 100, image: "Wmns(16).webp" },
    { id: 17, prod_name: "A Ma Maniére x Wmns Air Jordan 4 Retro 'While You Were Sleeping'",  price: 250, image: "Wmns(17).webp" },
    { id: 18, prod_name: "Wmns Air Jordan 4 Retro 'Orchid'",  price: 270, image: "Wmns(18).webp" },
    { id: 19, prod_name: "Wmns Air Jordan 11 Retro 'Bred Velvet'",  price: 230, image: "Wmns(19).webp" },
    { id: 20, prod_name: "Wmns Dunk Low 'Neapolitan'",  price: 75, image: "Wmns(20).webp" },
    { id: 21, prod_name: "Wmns Air Zoom Vomero 5 'Metallic Silver Blue Tint'",  price: 110, image: "Wmns(21).webp" },
    { id: 22, prod_name: "Wmns Samba OG 'Mineral Green'",  price: 110, image: "Wmns(22).webp" },
    { id: 23, prod_name: "Wmns Handball Spezial 'Corduroy Pack - Shadow Red'",  price: 115, image: "Wmns(23).webp" },
    { id: 24, prod_name: "Wmns Handball Spezial 'Wonder Taupe Gum'",  price: 120, image: "Wmns(24).webp" },
    { id: 25, prod_name: "Hello Kitty x Wmns Gazelle Indoor '50th Anniversary'",  price: 150, image: "Wmns(25).webp" },
    { id: 26, prod_name: "Hello Kitty x Wmns Adistar Cushion '50th Anniversary'",  price: 145, image: "Wmns(26).webp" },
    { id: 27, prod_name: "Wmns Gazelle Bold 'Auburn Icey Pink'",  price: 120, image: "Wmns(27).webp" },
    { id: 28, prod_name: "Wmns Dunk Low LX 'Ale Brown Ostrich'",  price: 60, image: "Wmns(28).webp" },
    { id: 29, prod_name: "Wmns Dunk Low 'Playful Pink Foam'",  price: 100, image: "Wmns(29).webp" },
    { id: 30, prod_name: "Wmns Dunk Low SE 'Double Swoosh'",  price: 150, image: "Wmns(30).webp" },
    { id: 31, prod_name: "Rick Owens Wmns Lunar Mega Tractor Boot 'Pearl'",  price: 4000, image: "Wmns(31).webp" }
   
    
];


const productList = document.getElementById("product-list");

function renderProducts(products) {
    productList.innerHTML = ""; 

   
    for (let i = 0; i < products.length; i++) {
        const product = products[i];

        const productCard = `
            <div class="product-card">
                <div class="product-image">
                    <img src="womens_prod/${product.image}" alt="${product.prod_name}">
                </div>
                <div class="product-info">
                    <p>${product.prod_name}</p>
                    <p class="price">$${product.price.toFixed(2)}</p>
                    <select id="womenSize" name="womenSize">
                        <option value="sizes">sizes</option>
                        <option value="4">4</option>
                        <option value="4.5">4.5</option>
                        <option value="5">5</option>
                        <option value="5.5">5.5</option>
                        <option value="6">6</option>
                        <option value="6.5">6.5</option>
                        <option value="7">7</option>
                        <option value="7.5">7.5</option>
                        <option value="8">8</option>
                        <option value="8.5">8.5</option>
                        <option value="9">9</option>
                        <option value="9.5">9.5</option>
                        <option value="10">10</option>
                        <option value="10.5">10.5</option>
                        <option value="11">11</option>
                        <option value="11.5">11.5</option>
                        <option value="12">12</option>
                    </select>
                </div>
            </div>
        `;

        
        productList.innerHTML += productCard;
    }
}


renderProducts(products);
