/*
Student ID: 24219703
Student Name: Albin Garcia
 */



const products = [
    { id: 1, prod_name: "Ben & Jerry's x Dunk Low SB 'Chunky Dunky'", price: 1200, image: "dk(1).webp" },
    { id: 2, prod_name: "Off-White x Dunk Low 'Lot 09 of 50'",  price: 600, image: "dk(2).webp" },
    { id: 3, prod_name: "Why So Sad? x Dunk Low SB 'The Predatory Bird'",  price: 350, image: "dk(3).webp" },
    { id: 4, prod_name: "Concepts x Dunk Low SB 'Orange Lobster'",  price: 300, image: "dk(4).webp" },
    { id: 5, prod_name: "Dunk Low SB 'Sandy Bodecker'",  price: 130, image: "dk(5).webp" },
    { id: 6, prod_name: "Jarritos x Dunk Low SB Special Box Friends & Family",  price: 2400, image: "dk(6).webp" },
    { id: 7, prod_name: "The Powerpuff Girls x Dunk Low Pro SB QS 'Blossom'",  price: 450, image: "dk(7).webp" },
    { id: 8, prod_name: "The Powerpuff Girls x Dunk Low Pro SB QS 'Buttercup'",  price: 300, image: "dk(8).webp" },
    { id: 9, prod_name: "The Powerpuff Girls x Dunk Low Pro SB QS 'Bubbles'",  price: 350, image: "dk(9).png" },
    { id: 10, prod_name: "Travis Scott x Air Jordan 1 Retro Low OG 'Reverse Mocha'",  price: 250, image: "j1(1).jpg" },
    { id: 11, prod_name: "Off-White x Air Jordan 1 Retro High OG 'UNC'",  price: 1500, image: "j1(2).jpg" },
    { id: 12, prod_name: "Travis Scott x Wmns Air Jordan 1 Retro Low OG SP 'Canary'",  price: 450, image: "j1(3).webp" },
    { id: 13, prod_name: "Air Jordan 1 High Golf 'University Blue'",  price: 250, image: "j1(4).webp" },
    { id: 14, prod_name: "Travis Scott x Air Jordan 1 Retro Low OG SP 'Velvet Brown'",  price: 1100, image: "j1(5).webp" },
    { id: 15, prod_name: "Travis Scott x Air Jordan 1 Retro Low OG SP 'Reverse Olive / Medium Olive'",  price: 200, image: "j1(6).webp" },
    { id: 16, prod_name: "Travis Scott x Air Jordan 1 Retro Low OG SP 'Black Phantom'",  price: 350, image: "j1(7).webp" },
    { id: 17, prod_name: "J. Balvin x Air Jordan 1 Retro OG High 'Colores Y Vibras' Sample",  price: 250, image: "j1(8).webp" },
    { id: 18, prod_name: "Off-White x Air Jordan 1 Retro High OG 'Chicago'",  price: 5000, image: "j1(9).webp" },
    { id: 19, prod_name: "Travis Scott x Air Jordan 1 Retro High OG 'Mocha'",  price: 1500, image: "j1(10).webp" },
    { id: 20, prod_name: "Air Jordan 1 Retro High OG 'Fearless'",  price: 250, image: "j1(11).webp" },
    { id: 21, prod_name: "Travis Scott x Dunk Low Premium QS SB 'Cactus Jack'",  price: 1100, image: "j1(12).webp" },
    { id: 22, prod_name: "Fragment Design x Travis Scott x Air Jordan 1 Retro Low",  price: 1000, image: "j1(13).webp" },
    { id: 23, prod_name: "Air Jordan 1 Retro High OG 'Chicago Lost & Found'",  price: 200, image: "j1(14).webp" },
    { id: 24, prod_name: "Marvel x Air Jordan 1 Retro High OG 'Next Chapter'",  price: 120, image: "j1(15).webp" },
    { id: 25, prod_name: "Air Jordan 4 Retro 'Black Cat' 2020",  price: 950, image: "j4(1).jpg" },
    { id: 26, prod_name: "Nike SB x Air Jordan 4 Retro SP 'Pine Green'",  price: 445, image: "j4(2).webp" },
    { id: 27, prod_name: "Air Jordan 4 Retro 'Military Black'",  price: 440, image: "j4(3).webp" },
    { id: 28, prod_name: "Air Jordan 4 Retro 'White Oreo'",  price: 350, image: "j4(4).webp" },
    { id: 29, prod_name: "Air Jordan 4 Retro 'University Blue'",  price: 450, image: "j4(5).webp" },
    { id: 30, prod_name: "Air Jordan 4 Retro 'Red Cement'",  price: 250, image: "j4(6).webp" },
    { id: 31, prod_name: "Air Jordan 4 Retro 'Red Cement'",  price: 270, image: "j4(7).webp" },
    { id: 32, prod_name: "Air Jordan 4 Retro 'Bred Reimagined'",  price: 270, image: "j4(8).webp" },
    { id: 33, prod_name: "Air Jordan 4 Retro 'White Thunder'",  price: 270, image: "j4(9).webp" },
    { id: 34, prod_name: "Off-White x Air Jordan 5 Retro SP 'Muslin'",  price: 500, image: "j5(1).jpg" },
    { id: 35, prod_name: "Air Jordan 11 Retro 'Space Jam' 2016",  price: 270, image: "j11(1).webp" },
    { id: 36, prod_name: "Air Jordan 11 Retro 'Cap and Gown'",  price: 650, image: "j11(2).webp" },
    { id: 37, prod_name: "Air Jordan 11 Retro 'Concord' 2018",  price: 380, image: "j11(3).webp" },
    { id: 38, prod_name: "Air Jordan 11 Retro 'Jubilee / 25th Anniversary'",  price: 300, image: "j11(4).webp" },
    { id: 39, prod_name: "Air Jordan 11 Retro 'Bred' 2019",  price: 450, image: "j11(5).jpg" },
    { id: 40, prod_name: "Air Jordan 11 Retro 'Cool Grey' 2021",  price: 450, image: "j11(6).webp" },
    { id: 41, prod_name: "Air Jordan 11 Retro 'Gratitude / Defining Moments'",  price: 240, image: "j11(7).webp" },
    { id: 42, prod_name: "Air Jordan 11 Retro 'Columbia / Legend Blue' 2024",  price: 380, image: "j11(8).webp" }
    
    
];


const productList = document.getElementById("product-list");

function renderProducts(products) {
    productList.innerHTML = ""; 

   
    for (let i = 0; i < products.length; i++) {
        const product = products[i];

        const productCard = `
            <div class="product-card">
                <div class="product-image">
                    <img src="mens_prod/${product.image}" alt="${product.prod_name}">
                </div>
                <div class="product-info">
                    <p>${product.prod_name}</p>
                    <p class="price">$${product.price.toFixed(2)}</p>
                    <select id="menSize" name="menSize">
                        <option value="sizes">sizes</option>
                        <option value="6">6</option>
                        <option value="6.5">6.5</option>
                        <option value="7">7</option>
                        <option value="7.5">7.5</option>
                        <option value="8">8</option>
                        <option value="8.5">8.5</option>
                        <option value="9">9</option>
                        <option value="9.5">9.5</option>
                        <option value="10">10</option>
                        <option value="10.5">10.5</option>
                        <option value="11">11</option>
                        <option value="11.5">11.5</option>
                        <option value="12">12</option>
                        <option value="12.5">12.5</option>
                        <option value="13">13</option>
                        <option value="13.5">13.5</option>
                        <option value="14">14</option>
                        <option value="15">15</option>
                    </select>
                </div>
            </div>
        `;

        
        productList.innerHTML += productCard;
    }
}


renderProducts(products);
