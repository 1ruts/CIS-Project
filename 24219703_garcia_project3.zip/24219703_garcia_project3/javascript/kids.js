/*
Student ID: 24219703
Student Name: Albin Garcia
 */

const products = [
    { id: 1, prod_name: "Air Jordan 11 Retro GS 'Columbia / Legend Blue' 2024", price: 200, image: "kds(1).webp" },
    { id: 2, prod_name: "Air Jordan 9 Retro PS 'Olive' 2024",  price: 140, image: "kds(2).webp" },
    { id: 3, prod_name: "Air Jordan 11 Retro GS 'Concord' 2018",  price: 100, image: "kds(3).webp" },
    { id: 4, prod_name: "Dunk Low GS 'Triple Pink'",  price: 90, image: "kds(4).webp" },
    { id: 5, prod_name: "Zoom Kobe 6 GS 'Reverse Grinch'",  price: 300, image: "kds(5).webp" },
    { id: 6, prod_name: "Air Jordan 11 Retro GS 'Gratitude / Defining Moments'",  price: 140, image: "kds(6).webp" },
    { id: 7, prod_name: "Air Jordan 4 Retro GS 'Bred Reimagined'",  price: 180, image: "kds(7).webp" },
    { id: 8, prod_name: "Air Jordan 4 Retro GS 'Military Blue' 2024",  price: 180, image: "kds(8).webp" },
    { id: 9, prod_name: "Air Jordan 4 Retro SE GS 'Wet Cement'",  price: 160, image: "kds(9).webp" },
    { id: 10, prod_name: "Air Jordan 3 Retro GS 'Cement Grey'",  price: 120, image: "kds(10).webp" },
    { id: 11, prod_name: "Air Jordan 12 Retro GS 'Barons'",  price: 150, image: "kds(11).webp" },
    { id: 12, prod_name: "Air Jordan 4 Retro GS 'Fear' 2024",  price: 140, image: "kds(12).webp" },
    { id: 13, prod_name: "9060 Big Kid Wide 'Rose Pink'",  price: 110, image: "kds(13).webp" },
    { id: 14, prod_name: "Zoom Kobe 5 GS 'X-Ray'",  price: 120, image: "kds(14).webp" },
    { id: 15, prod_name: "Air Jordan 14 Retro GS 'Black Toe' 2024",  price: 200, image: "kds(15).webp" },
    { id: 16, prod_name: "Air Jordan 4 Retro GS 'Platinum Gold'",  price: 110, image: "kds(16).webp" },
    { id: 17, prod_name: "Gazelle Bold J 'Wonder White Clear Sky'",  price: 65, image: "kds(17).webp" },
    { id: 18, prod_name: "Air Jordan 3 Retro OG PS 'Black Cement' 2024",  price: 120, image: "kds(18).webp" },
    { id: 19, prod_name: "Air Jordan 3 Retro PS 'Cement Grey'",  price: 90, image: "kds(19).webp" },
    { id: 20, prod_name: "Travis Scott x Air Jordan 1 Retro Low OG SP PS 'Black Phantom'",  price: 220, image: "kds(20).webp" },
    { id: 21, prod_name: "Travis Scott x Air Jordan 1 Retro Low OG SP PS 'Reverse Olive / Medium Olive'",  price: 140, image: "kds(21).webp" },
    { id: 22, prod_name: "Travis Scott x Air Jordan 1 Retro Low OG SP PS 'Canary'",  price: 200, image: "kds(22).webp" },
    { id: 23, prod_name: "Dunk Low PS 'Vintage Green'",  price: 80, image: "kds(23).webp" },
    { id: 24, prod_name: "Air Jordan 1 Retro High OG PS 'Artisanal Red'",  price: 90, image: "kds(24).webp" },
    { id: 25, prod_name: "Air Jordan 4 Retro GS 'White Thunder'",  price: 175, image: "kds(25).webp" },
    { id: 26, prod_name: "Air Jordan 11 PS Retro PS 'Bred Velvet'",  price: 115, image: "kds(26).webp" },
    { id: 27, prod_name: "Gazelle C 'Semi Pink Spark Lucid Blue'",  price: 150, image: "kds(27).webp" },
    { id: 28, prod_name: "Air Jordan 1 Retro High OG GS 'Midnight Navy'",  price: 100, image: "kds(28).webp" },
    { id: 29, prod_name: "9060 Little Kid 'Reflection Quarry Blue'",  price: 135, image: "kds(29).webp" },
    { id: 30, prod_name: "Air More Uptempo PS 'White Royal'",  price: 110, image: "kds(30).webp" },
    { id: 31, prod_name: "Air More Uptempo PS 'White Vintage Green'",  price: 95, image: "kds(31).webp" }
   
    
];


const productList = document.getElementById("product-list");

function renderProducts(products) {
    productList.innerHTML = ""; 

   
    for (let i = 0; i < products.length; i++) {
        const product = products[i];

        const productCard = `
            <div class="product-card">
                <div class="product-image">
                    <img src="kids_prod/${product.image}" alt="${product.prod_name}">
                </div>
                <div class="product-info">
                    <p>${product.prod_name}</p>
                    <p class="price">$${product.price.toFixed(2)}</p>
                    <select id="kidsSize" name="kidsSize">
                        <option value="sizes">sizes</option>
                        <option value="0">0</option>
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                        <option value="6">6</option>
                        <option value="7">7</option>
                        <option value="8">8</option>
                        <option value="9">9</option>
                        <option value="10">10</option>
                        <option value="11">11</option>
                        <option value="12">12</option>
                        <option value="13">13</option>
                        <option value="1-Kids">1</option>
                        <option value="2-Kids">2</option>
                        <option value="3-Kids">3</option>
                        <option value="4-Kids">4</option>
                        <option value="5-Kids">5</option>
                        <option value="6-Kids">6</option>
                        <option value="7-Kids">7</option>
                    </select>
                </div>
            </div>
        `;

        
        productList.innerHTML += productCard;
    }
}


renderProducts(products);
