/*
Student ID: 24219703
Student Name: Albin Garcia
 */

var front_photo = [
    {id: 1 , pord_name:"" , desc:"" , image:"snkrs1.jpg" },
    {id: 2 , pord_name:"" , desc:"" , image:"snkrs1.jpg" },
    {id: 3 , pord_name:"" , desc:"" , image:"snkrs1.jpg" },
    {id: 4 , pord_name:"" , desc:"" , image:"snkrs1.jpg" },
    {id: 5 , pord_name:"" , desc:"" , image:"snkrs1.jpg" },
    {id: 6 , pord_name:"" , desc:"" , image:"snkrs1.jpg" },
    {id: 7 , pord_name:"" , desc:"" , image:"snkrs1.jpg" },
    {id: 8 , pord_name:"" , desc:"" , image:"snkrs1.jpg" },
    {id: 9 , pord_name:"" , desc:"" , image:"snkrs1.jpg" },
    {id: 10 , pord_name:"" , desc:"" , image:"snkrs1.jpg" },
    {id: 11 , pord_name:"" , desc:"" , image:"snkrs1.jpg" },
    {id: 12 , pord_name:"" , desc:"" , image:"snkrs1.jpg" },
    {id: 13 , pord_name:"" , desc:"" , image:"snkrs1.jpg" },
    {id: 14 , pord_name:"" , desc:"" , image:"snkrs1.jpg" },
    {id: 15 , pord_name:"" , desc:"" , image:"snkrs1.jpg" },
    {id: 16 , pord_name:"" , desc:"" , image:"snkrs1.jpg" },
    {id: 17 , pord_name:"" , desc:"" , image:"snkrs1.jpg" },
    {id: 18 , pord_name:"" , desc:"" , image:"snkrs1.jpg" },
    {id: 19 , pord_name:"" , desc:"" , image:"snkrs1.jpg" },
    {id: 20 , pord_name:"" , desc:"" , image:"snkrs1.jpg" },
    {id: 21 , pord_name:"" , desc:"" , image:"snkrs1.jpg" },
    {id: 22 , pord_name:"" , desc:"" , image:"snkrs1.jpg" },
    {id: 23 , pord_name:"" , desc:"" , image:"snkrs1.jpg" },
    {id: 24 , pord_name:"" , desc:"" , image:"snkrs1.jpg" }
    

];

var ind_front_photo = "";

for(var i = 0; i < front_photo.length; i++ ){
    ind_front_photo += 
   ``;
}
document.getElementById("front_page").innerHTML = ind_front_photo;